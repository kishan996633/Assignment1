package TestAutomationAssignment;

import AutomationAssignmentPage.HomePage;

public class TestHomePage {

	public static void main(String[] args) throws InterruptedException, Exception {
		HomePage homePage = new HomePage(); 
		homePage.launchWebsite("https://www.fitpeo.com/"); 
		homePage.clickRevenueCalculator();

		homePage.getSliderLeftPosition();

		homePage.moveSliderToPercentage(1000, 0, 2000);

		homePage.clickOnValueTextField(1000);

		homePage.validateSliderAndTextField(1000);

		homePage.selectCptCodes("CPT-99091");
		homePage.selectCptCodes("CPT-99453");
		homePage.selectCptCodes("CPT-99454");
		homePage.selectCptCodes("CPT-99474");

		homePage.validateTRReimbursement();

		Thread.sleep(10000);
		homePage.closeBrowser();

	}

}