package AutomationAssignmentPage;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class HomePage {

	public WebDriver driver;

	public WebElement revenueCalculator;

	// Public XPath for the 'Revenue Calculator' element
	public String revenueCalculatorXpath = "//div[text()='Revenue Calculator']";

	// XPath for the parent container of the slider
	public String sliderContainerXpath = "//h4[contains(text(), 'Medicare Eligible Patients')]/following::div[contains(@class, 'MuiBox-root')]/span[contains(@class, 'MuiSlider')]";

	public WebElement valueTextField;

	// XPath for the input field where the count is entered
	public String valueTextFieldXpath = "//span[contains(text(), 'Patients')]/preceding::div/input";

	// Constructor to initialize WebDriver
	public HomePage() {
		System.setProperty("webdriver.edge.driver", "./Driver/edgedriver.exe");
		WebDriverManager.edgedriver().setup();
		this.driver = new EdgeDriver();
		driver.manage().window().maximize();
	}

	// Method to launch the website
	public void launchWebsite(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000); // Wait for the page to load
	}

	// Method to click the 'Revenue Calculator' element
	public void clickRevenueCalculator() throws InterruptedException {
		revenueCalculator = driver.findElement(By.xpath(revenueCalculatorXpath));
		revenueCalculator.click();

		Thread.sleep(2000);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, 500);");
	}

	// Method to get the current 'left' position of the slider thumb from the
	// 'style' attribute
	public String getSliderLeftPosition() {
		// Find the slider thumb element
		WebElement sliderThumb = driver.findElement(By.xpath("//span[contains(@class, 'MuiSlider-thumb')]"));

		// Get the inline style attribute
		String style = sliderThumb.getAttribute("style");

		// Extract and return the 'left' position from the style string
		String leftPosition = extractCSSProperty(style, "left");
		return leftPosition;
	}

	// Method to move the slider by updating the left position
	public void moveSliderToPercentage(int targetValue, int minValue, int maxValue) {
		// Calculate the percentage based on the target value
		double percentage = ((double) targetValue - minValue) / (maxValue - minValue) * 100;

		// Find the slider thumb element
		WebElement sliderThumb = driver.findElement(By.xpath("//span[contains(@class, 'MuiSlider-thumb')]"));

		// Get the current left position of the slider
		String currentLeftPosition = getSliderLeftPosition();
		System.out.println("Current left position: " + currentLeftPosition);

		// Use JavaScript to update the 'left' style attribute of the slider thumb
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Set the new left position to the calculated percentage
		js.executeScript("arguments[0].style.left = '" + percentage + "%';", sliderThumb);

		// Update the 'aria-valuenow' and 'value' attributes to reflect the new value
		WebElement slider = driver.findElement(By.xpath("//span[contains(@class, 'MuiSlider-thumb')]"));
		js.executeScript("arguments[0].setAttribute('aria-valuenow', '" + targetValue + "');", slider);
		js.executeScript("arguments[0].setAttribute('value', '" + targetValue + "');", slider);

		sliderThumb.click();
		System.out.println("Slider moved to " + targetValue + " with a left position of " + percentage + "%");
	}

	// Utility method to extract a CSS property value from a style string
	private String extractCSSProperty(String style, String property) {
		String[] styles = style.split(";");
		for (String s : styles) {
			if (s.contains(property)) {
				return s.split(":")[1].trim();
			}
		}
		return "Property not found";

	}

	public void clickOnValueTextField(int newValue) throws AWTException {
		valueTextField = driver.findElement(By.xpath(valueTextFieldXpath));
		valueTextField.click();
		Robot robot = new Robot();

		// Select all text (Ctrl + A) to clear the field
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		// Simulate pressing BACKSPACE to clear the selected text
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
		robot.keyRelease(KeyEvent.VK_BACK_SPACE);

		// Convert the integer to a string
		String newValueStr = String.valueOf(newValue);

		// Loop through each character in the integer value
		for (char c : newValueStr.toCharArray()) {
			// Simulate typing each character (digit)
			robot.keyPress(KeyEvent.getExtendedKeyCodeForChar(c));
			robot.keyRelease(KeyEvent.getExtendedKeyCodeForChar(c));
		}
	}

	// Method to retrieve the slider value
	public int getSliderValue() {
		WebElement slider = driver.findElement(By.xpath("//span[contains(@class, 'MuiSlider-thumb')]"));
		String sliderValue = slider.getAttribute("aria-valuenow");
		return Integer.parseInt(sliderValue);
	}

	// Method to retrieve the text field value
	public int getTextFieldValue() {
		valueTextField = driver.findElement(By.xpath(valueTextFieldXpath));
		String textFieldValue = valueTextField.getAttribute("value");
		return Integer.parseInt(textFieldValue);
	}

	// Method to validate whether the text field and slider values are the same
	public boolean validateSliderAndTextField(int newValue) throws AWTException {
		clickOnValueTextField(newValue);

		// Retrieve the value from the text field and the slider
		int textFieldValue = getTextFieldValue();
		int sliderValue = getSliderValue();

		// Comparing the values
		if (textFieldValue == sliderValue) {
			System.out.println("Validation Passed: Text field and slider values are the same.");
			return true;
		} else {
			System.out.println(
					"Validation Failed: Text field value is " + textFieldValue + " but slider value is " + sliderValue);
			return false;
		}
	}

	public void selectCptCodes(String dynamicText) {

		// Create the dynamic XPath
		String xpath = "//p[text()='" + dynamicText + "']/ancestor::div[contains(@class, 'MuiBox-root')]/label";

		// Locate the <p> element using the dynamic XPath
		WebElement checkBox = driver.findElement(By.xpath(xpath));

		// Disable the checkbox
		checkBox.click();
		System.out.println("Checkbox is now enabled.");

	}

	public void validateTRReimbursement() {
		WebElement element = driver.findElement(By.xpath("(//p[contains(@class, 'MuiTypography-body2')])[4]"));

		String text = element.getText();

		System.out.println(text);
	}

// Method to close the browser
	public void closeBrowser() {
		if (driver != null) {
			driver.quit();
		}

	}

}